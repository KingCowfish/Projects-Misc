﻿namespace SkiaSharpFormsDemos.Effects
{
	public partial class EffectsHomePage : HomeBasePage
    {
		public EffectsHomePage ()
		{
			InitializeComponent ();
		}
	}
}