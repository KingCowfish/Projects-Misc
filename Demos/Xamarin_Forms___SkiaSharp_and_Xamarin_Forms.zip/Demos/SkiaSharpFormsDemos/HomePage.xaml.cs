﻿using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace SkiaSharpFormsDemos
{
    public partial class HomePage : HomeBasePage
    {
        public HomePage()
        {
            InitializeComponent();
        }
    }
}
