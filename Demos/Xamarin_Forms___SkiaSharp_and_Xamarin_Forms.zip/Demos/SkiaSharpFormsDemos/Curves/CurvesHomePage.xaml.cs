﻿using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace SkiaSharpFormsDemos.Curves
{
    public partial class CurvesHomePage : HomeBasePage
    {
        public CurvesHomePage()
        {
            InitializeComponent();
        }
    }
}
