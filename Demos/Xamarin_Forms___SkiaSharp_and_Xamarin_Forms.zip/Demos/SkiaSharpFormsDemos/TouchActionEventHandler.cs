﻿namespace TouchTracking
{
    public delegate void TouchActionEventHandler(object sender, TouchActionEventArgs args);
}
