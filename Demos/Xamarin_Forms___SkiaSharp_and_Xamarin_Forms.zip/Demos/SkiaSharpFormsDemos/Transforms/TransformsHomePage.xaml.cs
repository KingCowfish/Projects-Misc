﻿using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace SkiaSharpFormsDemos.Transforms
{
    public partial class TransformsHomePage : HomeBasePage
    {
        public TransformsHomePage()
        {
            InitializeComponent();
        }
    }
}
